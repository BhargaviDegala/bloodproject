import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-def',
  templateUrl: './def.component.html',
  styleUrls: ['./def.component.css']
})
export class DefComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
