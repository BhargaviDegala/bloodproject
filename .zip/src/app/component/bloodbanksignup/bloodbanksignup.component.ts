import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bloodbanksignup',
  templateUrl: './bloodbanksignup.component.html',
  styleUrls: ['./bloodbanksignup.component.css']
})
export class BloodbanksignupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
