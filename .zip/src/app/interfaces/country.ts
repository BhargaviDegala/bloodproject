export class Country {
    constructor(public country_name:string="", public country_id:number=null)
    {}
}
