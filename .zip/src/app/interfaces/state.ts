export class State {
    constructor(public state_id:number=null,public state_name:string="",public country_id:number=null)
    {}
}
