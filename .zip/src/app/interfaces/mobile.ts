export class Mobile {
    constructor(public mobile_no:number=null)
    {

        
    }
}
