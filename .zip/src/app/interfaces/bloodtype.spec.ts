import { Bloodtype } from './bloodtype';

describe('Bloodtype', () => {
  it('should create an instance', () => {
    expect(new Bloodtype()).toBeTruthy();
  });
});
