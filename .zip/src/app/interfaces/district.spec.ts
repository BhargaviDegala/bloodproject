import { District } from './district';

describe('District', () => {
  it('should create an instance', () => {
    expect(new District()).toBeTruthy();
  });
});
