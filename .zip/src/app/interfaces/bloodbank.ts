export class Bloodbank {
    constructor(public bloodbank_name:string="",public bloodbank_location:string="",public bloodbank_contactno:string="",public bloodbank_username:string="",public bloodbank_password:string=""){}
}
