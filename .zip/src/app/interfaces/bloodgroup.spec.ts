import { Bloodgroup } from './bloodgroup';

describe('Bloodgroup', () => {
  it('should create an instance', () => {
    expect(new Bloodgroup()).toBeTruthy();
  });
});
