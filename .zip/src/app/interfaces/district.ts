export class District {
    constructor(public district_id:number=null,public district_name:string="",public state_id=null)
    {}
}
