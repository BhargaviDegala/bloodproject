export class Admin {
    constructor(public admin_username:string="",public admin_password="")
    {

    }
}
