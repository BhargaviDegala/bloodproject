import { Benfsignup1 } from './benfsignup1';

describe('Benfsignup1', () => {
  it('should create an instance', () => {
    expect(new Benfsignup1()).toBeTruthy();
  });
});
