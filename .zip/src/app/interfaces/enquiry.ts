export class Enquiry {
    constructor(public enquiry_name:string="",public enquiry_mobileno:number=null,public enquiry_message:string="")
    {

    }
}
