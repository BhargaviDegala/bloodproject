export class Bloodgroup {
    constructor(public bloodgroup_name:string="", public bloodgroup_id:number=null)
    {}
}
