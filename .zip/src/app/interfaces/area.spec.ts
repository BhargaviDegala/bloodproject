import { Area } from './area';

describe('Area', () => {
  it('should create an instance', () => {
    expect(new Area()).toBeTruthy();
  });
});
