export class Signup1 {
    constructor(public user_fullname:string="",public user_age:number=null,public gender_name:string="",public bloodgroup_name:string="",public benf_accepted_bloodgroup:string="", public user_mobile1:number=null,public user_mobile2:number=null,public user_emailid:string="",public user_fulladdress:string="",public country_name:string="",public state_name:string="",public district_name:string="",public area_name:string="",public user_pincode:number=null)
    {}
}
