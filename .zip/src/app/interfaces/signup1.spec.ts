import { Signup1 } from './signup1';

describe('Signup1', () => {
  it('should create an instance', () => {
    expect(new Signup1()).toBeTruthy();
  });
});
