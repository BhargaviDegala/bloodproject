import { Bloodbank } from './bloodbank';

describe('Bloodbank', () => {
  it('should create an instance', () => {
    expect(new Bloodbank()).toBeTruthy();
  });
});
