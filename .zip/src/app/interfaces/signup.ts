export class Signup {
    constructor(public user_fullname:string="",public user_age:number=null,public user_gender:number=null,public user_bloodgroup:number=null,public user_mobile1:number=null,public user_mobile2:number=null,public user_emailid:string="",public user_fulladdress:string="",public user_country:number=null,public user_state:number=null,public user_district:number=null,public user_area:number=null,public user_pincode:number=null,public userstatus:number=null)
    
    {

    }
}
