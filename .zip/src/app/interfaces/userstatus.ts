export class Userstatus {
    constructor(public user_status:string="", public id_user:number=null)
    {}
}

