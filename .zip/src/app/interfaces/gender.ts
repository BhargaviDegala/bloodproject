export class Gender {
    constructor(public gender_name="", public gender_id:number=null)
    {

    }
}
