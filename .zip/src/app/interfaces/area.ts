export class Area {
    constructor(public area_id:number=null,public area_name:string="",public district_id=null)

    {}
}
