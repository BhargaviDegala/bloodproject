export class Accbloodgroup {
    constructor(public benf_accepted_bloodgroup:number=null,public bloodgroup_id:number=null)
    {}
}
