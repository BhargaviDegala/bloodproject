import { Accbloodgroup } from './accbloodgroup';

describe('Accbloodgroup', () => {
  it('should create an instance', () => {
    expect(new Accbloodgroup()).toBeTruthy();
  });
});
