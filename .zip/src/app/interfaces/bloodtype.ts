export class Bloodtype {
    constructor(public blood_type_name:string="",public blood_type_id:number=null)
    {}
}

