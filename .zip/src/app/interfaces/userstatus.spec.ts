import { Userstatus } from './userstatus';

describe('Userstatus', () => {
  it('should create an instance', () => {
    expect(new Userstatus()).toBeTruthy();
  });
});
