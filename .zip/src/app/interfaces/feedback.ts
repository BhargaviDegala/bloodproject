export class Feedback {
    constructor(public feedback_name:string="",public feedback_emaill:string="",public feedback_message:string="")
    {

    }
}
