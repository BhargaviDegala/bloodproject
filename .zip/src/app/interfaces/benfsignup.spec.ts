import { Benfsignup } from './benfsignup';

describe('Benfsignup', () => {
  it('should create an instance', () => {
    expect(new Benfsignup()).toBeTruthy();
  });
});
